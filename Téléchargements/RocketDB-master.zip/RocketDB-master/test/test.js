/*
  author : Sacha Charbit
  Github : @sacharbit
  linkedin : https://www.linkedin.com/in/sacha-charbit-004502b9/
*/
var csv_handler = require('csv-handler');
console.log(csv_handler);
var db = require('../src/RocketDB')({importCSV : csv_handler.importCSV, exportCSV : csv_handler.exportCSV, splitSize : 100000});
var colors = require('colors');
var fs = require('fs');

var check = function(returned, nameTest, checkResponse){
  if(returned.status == "success" && typeof(wantedresult) == 'undefined')
    console.log((nameTest +" : " + returned.response).green);
  else if(checkResponse !== undefined && returned.response == checkResponse)
    console.log((nameTest +" : " + returned.response).green);
  else console.log((nameTest +" : " + returned.response).red);
}

var checkValue = function(returned, nameTest, checkValue){
  if(returned == checkValue) console.log((nameTest +" : " + returned).green);
  else console.log((nameTest +" : " + returned).red);
}

check(db.insertTable("nametable", "userId", {"userId" : "String", "username" : "String", "name" : "String", "lastname" : "String", age : 'Number'}),
      "Creating a table");

check(db.insertLine("nametable", {userId : 'oko', username : 'igjhgg', name : 'hu', lastname : 'iuh', age:21}),
      "Inserting a line in a table");

check(db.insertLine("nametable", {userId : 'oko', username : 'actualbeautifulusername', name : 'actualbeautifulname', lastname : 'actualbeautifullastname', age:21}),
      "Inserting a line in a table with already existing key",
      "Error: oko is already in the database. Add 'with allow_updates' to the query to update it anyway.");

check(db.insertLine("nametable",
      {userId : 'oko', username : 'actualbeautifulusername', name : 'actualbeautifulname', lastname : 'actualbeautifullastname', age:21}, true),
      "Inserting a line in a table with allow_updates");

check(db.backupData(), "Saving data in a JSON file.");

check(db.search("nametable", ["oko"]), "Searching data in the database without condition");
check(db.search("nametable", null, ["username == 'actualbeautifulusername'"]), "Searching data with 1 condition");
check(db.sum("nametable", null, ["username == 'actualbeautifulusername'"], 'age'), "sum of age", 21);
check(db.count("nametable", null, ["username == 'actualbeautifulusername'"], 'age'), "count of users", 1);

check(db.deleteLine("nametable", "oko"), "Deleting a line");
// check(db.deleteTable("nametable"), "Deleting a table.");
checkValue(db.getSplitSize(), "Get split size", 100000);
db.backupData();
db.loadData();
db.insertLine("")
check(db.insertTable("player", "id", {id: 'Number', Player : 'String', height :'Number', weight : 'Number', collage : 'String', born : 'Number', birth_city : 'String', birth_state : 'String'}), "Insert the table player");
db.importCSV("player", "test/Players.csv", function(){
  db.backupData();
  db.loadData();
  var resp = db.mean("player", null, ["height == 180"], "weight");
  check(db.createIndex("player", "height"), "Create an index of a key");
  var resp = db.count("player", null, [true], "id");
  db.backupData();
  db.exportCSV('player');
});
